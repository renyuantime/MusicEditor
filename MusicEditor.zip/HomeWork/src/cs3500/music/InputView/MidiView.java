package cs3500.music.InputView;

import javax.sound.midi.InvalidMidiDataException;

/**
 * Created by ErinZhang on 3/15/16.
 */

public interface MidiView extends View {
  @Override
  void pause() throws InvalidMidiDataException;
  @Override
  void display() throws InterruptedException;
}
