package cs3500.music.InputView;

import javax.sound.midi.InvalidMidiDataException;

/**
 * Created by ErinZhang on 3/17/16.
 */
public interface View {
  /**
   * Display a view of a music editor starting at a given beat
   */
  void display() throws InterruptedException;

  /**
   * Pause the music/view
   * @throws InvalidMidiDataException
   */
  void pause() throws InvalidMidiDataException;
}
