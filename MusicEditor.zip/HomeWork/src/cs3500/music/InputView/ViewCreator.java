package cs3500.music.InputView;

import cs3500.music.InputModel.MusicEditorImpl;

/**
 * Created by Marija on 3/18/2016.
 */
public class ViewCreator {

  public static View create(String viewType, MusicEditorImpl model) {
    if (viewType.equals("console")) {
      return new ConsoleViewImpl(model);
    }
    else if (viewType.equals("gui")) {
      return new GuiViewFrame(model);
    }
    else if (viewType.equals("midi")) {
      return new MidiViewImpl(model);
    }
    else if (viewType.equals("combined")) {
      return new CombinedViewImpl(model);
    }
    else {
      throw new IllegalArgumentException("Wrong Model Type");
    }
  }
}
