package cs3500.music;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import javax.sound.midi.InvalidMidiDataException;

import cs3500.music.InputModel.MusicEditorImpl;
import cs3500.music.InputModel.MusicEditorModel;
import cs3500.music.adapter.CompositViewAdapter;
import cs3500.music.adapter.InputModelAdapter;
import cs3500.music.controller.ControllerImp;
import cs3500.music.model.HeadBeat;
import cs3500.music.model.IMusic;
import cs3500.music.model.MusicModel;
import cs3500.music.model.Pitch;
import cs3500.music.util.CompositionBuilder;
import cs3500.music.util.MusicReader;
import cs3500.music.view.GuiView;
import cs3500.music.view.IMusicView;
import cs3500.music.view.ViewFactory;

/**
 * Created by renyuan on 3/29/16.
 */
public class MusicEditor {

  public static void main(String[] args) throws IOException, InvalidMidiDataException,
          InterruptedException {

    MusicModel.Builder mb = new MusicModel.Builder();

    File file = new File(args[0]);
    FileReader fr = new FileReader(file);

    IMusic n11 = MusicReader.parseFile(fr, mb);


    HeadBeat hb= (HeadBeat) n11.getCollections().get(new Pitch(41)).get(0);
//    System.out.print(hb.getPitch().toString());



    CompositionBuilder<MusicEditorModel> builder = new MusicEditorImpl.Builder();
    MusicReader reader = new MusicReader();


      try{
        reader.parseFile(new FileReader(file),builder);}
      catch (FileNotFoundException e){
        e.printStackTrace();
      }
      MusicEditorModel mm = builder.build();

      MusicEditorImpl.Builder mb1 = new MusicEditorImpl.Builder();

//    MusicReader m1 = MusicReader.parseFile(fr,mb);




      // use my model to create a modeladapter that can work for their views;
       MusicEditorModel  modeladapter = new InputModelAdapter((MusicModel) n11);


         GuiView vadpt = new CompositViewAdapter(mm);


    IMusicView mv =  new ViewFactory().makeView(args[1]);

        ControllerImp cm = new ControllerImp(n11, mv);
//          ControllerImp cm = new ControllerImp(n11, vadpt);




}

}



