package cs3500.music.adapter;

/**
 * Created by renyuan on 4/17/16.
 */
public interface IAdapter  {
}
