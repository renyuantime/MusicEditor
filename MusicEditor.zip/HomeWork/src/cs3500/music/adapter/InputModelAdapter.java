package cs3500.music.adapter;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;

import cs3500.music.InputModel.MusicEditorImpl;
import cs3500.music.InputModel.MusicEditorModel;
import cs3500.music.InputModel.Note;
import cs3500.music.InputModel.NoteImpl;
import cs3500.music.model.HeadBeat;
import cs3500.music.model.IBeat;
import cs3500.music.model.MusicModel;
import cs3500.music.model.Pitch;

/**
 * Created by renyuan on 4/19/16.
 */
  public class InputModelAdapter implements MusicEditorModel {
  MusicModel m;


  public InputModelAdapter(MusicModel m) {
    this.m = m;

  }



  /**
   * Add a note to the song <></>If a note is added to an existing note, the old note would be
   * replaced by the new note<></>
   *
   * @param newNote a note with a given pitch at a given time
   */
  @Override
  public void addNote(Note newNote) {
    int start = newNote.getStartBeat();
    int end =newNote.getEndBeat();
    int ins =newNote.getInstrument();
    int pn =newNote.getPitchIdx();
    int volume =newNote.getVolume();

    cs3500.music.model.Note mynote = new cs3500.music.model.Note(new Pitch(pn),end-start);
    mynote.Set(start,end,ins,pn,volume);

   m.addNote(mynote,start);

  }

  /**
   * Edit a note from the song to change its length
   *
   * @param note a note with a given pitch at a given time
   */
  @Override
  public void editNote(Note note, int lenChange) {

  }

  /**
   *  @param pitchIdx
   * @param startBeat

   * @param duration
   */
  @Override
  public void removeNote(int pitchIdx, int startBeat, int duration) {

  }

  /**
   * remove a given note from a music editor
   */
  @Override
  public void removeNote1(Note note) {

  }

  /**
   * move a given note to a new location
   *
   * @param oldNote an existing note that needed to be removed
   * @param newNote a new note. the old note will be moved to this location
   */
  @Override
  public void moveNote(Note oldNote, Note newNote) {

  }

  /**
   * Determine if the given note is in the treemap
   *
   * @param note a given note with duration and pitch
   * @return true if the note is in the map
   */
  @Override
  public boolean containsNote(Note note) {
    return false;
  }

  /**
   * Given a new song, this new song will be added to the old song. These two songs will be played
   * simultaneously. If some notes are overlapped, play them together, and keep playing until the
   * the note with the longer beat is finished playing.
   *
   * @param song a new song that needed to be added to the current song
   */
  @Override
  public void playSimul(MusicEditorImpl song) {

  }

  /**
   * Given a new song, this new song will be added to the old song. But this new song is played
   * after the current song is finished playing.
   *
   * So if the last beat of the current song is 2, the first beat of the new song is played at 3.
   *
   * @param song a new song that needed to be played consecutively after the first song.
   */
  @Override
  public void playConsec(MusicEditorImpl song) {

  }

  /**
   * Get the current view of a piece of song
   *
   * @return a string containing all notes in a song
   */
  @Override
  public String renderSong() {

    return m.print();
  }

  /**
   * Get the current TreeMap of this music editor
   *
   * @return the current treemap consisted of beats and notes
   */
  @Override
  public TreeMap getMap() {
    return null;
  }

  /**
   * Retrieve all the notes at a specific beat
   *
   * @param beat given beat
   * @return notes in a beat
   */
  @Override
  public List<Note> getNotesAtBeat(int beat) {
    //get a list of head beats
    List<HeadBeat> lohb = m.getListHeadBeat();
    List<HeadBeat> lohb1 = new ArrayList<>();

    //get the headbeat at current beat;
    for(int i =0;i<lohb.size();i++){
      HeadBeat hb = lohb.get(i);
      if(hb.getPosition() == beat){
        lohb1.add(hb);
      }
    }

    List<Note>  lon = new ArrayList<>();

    //transfer  a list of head beats to list of notes;
    for(int i=0; i<lohb1.size();i++){
      //information of my model
      HeadBeat hb = lohb.get(i);
      Pitch p = hb.getPitch();
      int pitchrank = p.getPitchRank();
      int octave = p.getOctave();
      int startpositoin  = hb.getPosition();
      int end = hb.getEnd();
      int instrument = hb.getInstrument();
      int volume = hb.getVolume();

      // translate information for their model

      lon.add(new NoteImpl(cs3500.music.InputModel.Pitch.getPitch(pitchrank-1),octave,
              startpositoin,end,instrument,volume));
    }




    return lon;

  }

  /**
   * Get the tempo
   */
  @Override
  public int getTempo() {
    return this.m.getTempo();
  }

  /**
   * update the tempo
   */
  @Override
  public void setTempo(int tempo) {
    this.m.setTempo(tempo);
  }

  /**
   * Get the highest pitch
   *
   * @return index of highest pitch within range [0, 120]
   */
  @Override
  public int getHighPitch() {

    Set<Pitch> lop = m.getCollections().keySet();
    ArrayList<Pitch> lop1 = new ArrayList<Pitch>();
    ArrayList<Pitch> lop2 = new ArrayList<Pitch>();


    for (Pitch p : lop) {
      TreeMap<Integer, IBeat> hm1 = m.getCollections().get(p);
      Collection c1 = hm1.values();
      if (!c1.isEmpty()) {
        lop1.add(p);
      }
    }
    int min = lop1.get(0).hashCode();


    // get the pitches that are supposed to be displayed;
    int max = lop1.get(lop1.size() - 1).hashCode();
    for (int l = min; l < max + 1; l++) {
      Pitch p1 = new Pitch(l);
      lop2.add(p1);
    }

    //reverse the list
    Collections.reverse(lop2);


      List<Integer> lon = new ArrayList<>();
     for(Pitch p: lop2){
       lon.add(p.pitchNumber());
     }


    return Collections.max(lon);
  }

  /**
   * Get the lowest pitch
   *
   * @return index of lowest pitch within range [0, 120]
   */
  @Override
  public int getLowPitch() {
    Set<Pitch> sop = m.getCollections().keySet();
    List<Integer> lon = new ArrayList<>();
    for(Pitch p: sop){
      lon.add(p.pitchNumber());
    }
    return Collections.min(lon);
  }

  /**
   * Get the highest beat
   *
   * @return index of highest beat
   */
  @Override
  public int getHighBeat() {
    return m.getSize();
  }

  /**
   * Get the highest beat
   *
   * @return index of lowest beat, cannot be below 0
   */
  @Override
  public int getLowBeat() {
    return 0;
  }

  @Override
  public List<Note> getAll() {

    //get a list of head beats
    List<HeadBeat> lohb = m.getListHeadBeat();


    List<Note>  lon = new ArrayList<>();

    //transfer  a list of head beats to list of notes;
    for(int i=0; i<lohb.size();i++){
      //information of my model
      HeadBeat hb = lohb.get(i);
      Pitch p = hb.getPitch();
      int pitchrank = p.getPitchRank();
      int octave = p.getOctave();
      int startpositoin  = hb.getPosition();
      int end = hb.getEnd();
      int instrument = hb.getInstrument();
      int volume = hb.getVolume();

      // translate information for their model

      lon.add(new NoteImpl(cs3500.music.InputModel.Pitch.getPitch(pitchrank-1),octave,
              startpositoin,end,instrument,volume));
    }

    return  lon;


  }
}
