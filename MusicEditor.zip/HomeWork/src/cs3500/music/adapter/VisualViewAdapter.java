package cs3500.music.adapter;

import java.awt.*;
import java.awt.event.KeyListener;
import java.awt.event.MouseListener;
import java.util.ArrayList;

import javax.sound.midi.InvalidMidiDataException;

import cs3500.music.InputModel.MusicEditorModel;
import cs3500.music.InputView.GuiViewFrame;
import cs3500.music.model.IMusic;
import cs3500.music.view.GuiView;

/**
 * Created by renyuan on 4/17/16.
 */

public class VisualViewAdapter  implements IAdapter,GuiView {
      GuiViewFrame gf;

  /**
   * Creates a new GuiView
   */
  public VisualViewAdapter(MusicEditorModel m) {   // suppose to use IMusic Interface
    gf = new GuiViewFrame(m);

  }

  /**
   *
   * @param kbd
   */
  @Override
  public void addKeyListener(KeyListener kbd) {
     gf.addKeyListener(kbd);

  }

  @Override
  public void resetFocus() {
    gf.setFocusable(true);
    gf.requestFocus();
    gf.resetFocus();
  }

  @Override
  public void resume() {
    gf.display();
  }

  /**
   *  @param x
   * @param y
   */
  @Override
  public void move1(int x, int y) {

  }

  /**
   *  @param x
   * @param y

   * @param duration

   * @param instrument

   * @param volume
   */
  @Override
  public void move2(int x, int y, int duration, int instrument, int volume) {

  }

  @Override
  public void scrollright() {
     gf.scrollRight();
  }

  @Override
  public void scrollleft() {
      gf.scrollLeft();
  }

  @Override
  public void scrollup() {
      gf.scrollUp();
  }

  @Override
  public void scrolldown() {
      gf.scrollDown();
  }

  @Override
  public void scrollEnd() {
    gf.end();
  }

  @Override
  public void scrollBegin() {
     gf.home();
  }

  /**
   *  @param x
   * @param y

   * @param duration

   * @param instrument

   * @param volume
   */
  @Override
  public void addNote(int x, int y, int duration, int instrument, int volume) {

          x= x*20+40;
          y = y*20+40;

       gf.addNoteFromXandY(x,y,duration);

       gf.repaint();

  }

  /**
   *  @param x
   * @param y
   */
  @Override
  public void remove(int x, int y) {

    x= x*20+40;
    y = y*20+40;

    gf.removeNoteFromXandY(x,y);
    gf.repaint();

  }

  @Override
  public void stop() {
   gf.pause();
  }

  /**
   *

   * @param lop
   */
  @
          Override
  public void deleteAll(ArrayList<int[]> lop) {

  }

  /**
   *

   * @param mh
   */
  @
          Override
  public void addMouseListener(MouseListener mh) {
     gf.addMouseListener(mh);
  }

  /**
   *

   * @param m
   */
  @
          Override
  public void setModel(IMusic m) {

  }

  @Override
  public Point getCursorPostion() {
    return null;
  }

  @Override
  public int getScrollBarx() {
    return 0;
  }

  @Override
  public int getScrollBary() {
    return 0;
  }

  /**
   * initialize the view
   *
   * @param m the music is passed to model
   */
  @Override
  public void initialize(IMusic m) throws InterruptedException, InvalidMidiDataException {

         gf.display();
  }
}
