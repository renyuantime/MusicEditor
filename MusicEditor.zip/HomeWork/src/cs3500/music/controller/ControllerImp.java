package cs3500.music.controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import javax.sound.midi.InvalidMidiDataException;
import javax.swing.*;

import cs3500.music.model.HeadBeat;
import cs3500.music.model.IBeat;
import cs3500.music.model.IMusic;
import cs3500.music.model.MusicModel;
import cs3500.music.model.Note;
import cs3500.music.model.Pitch;
import cs3500.music.view.CompositeView;
import cs3500.music.view.GuiView;
import cs3500.music.view.IMusicView;
import cs3500.music.view.MidiViewImpl;

/**
 * Created by renyuan on 3/28/16.
 */



  // an implementation of IController, which is for controlling the music model and views. User
  //can add notes, remove notes, move notes at the composition through the controller




  // the controller is supposed to use model to feed the view to paint or make sound.
  // so the view
public class ControllerImp implements IController,ActionListener {


  private IMusic model;
  private GuiView view;
  private int x;  // to store x coordinate
  private int y;  // to store y coordinate
  private ArrayList<int[]> lop;
  private HashMap<Integer, Integer> hm;
  public MouseHandler mh;    // Making public because of testing purpose
  public KeyboardHandler kh;  //Making public because of testing purpose
  private StringBuilder sb;  // to store operation information
  private  Timer t; // timer for controller to update view baed on the model in the controller


  // constructor
  public ControllerImp(IMusic m, IMusicView v)
          throws InvalidMidiDataException, InterruptedException {

    //initialize some fields
    this.model = m;
    hm = new HashMap<>();
    lop = new ArrayList<>();
    sb = new StringBuilder();


    //decide what specific view is the input view, if its not GuiView, it does not need controller.
    if (v instanceof GuiView) {
      this.view = (GuiView) v;
     t= new Timer(model.getTempo()/4000,this);
      configureKeyBoardListener();
      v.initialize(m);


      view.resetFocus();

    } else if (v instanceof MidiViewImpl) {
      ((MidiViewImpl) v).setFlag(true);
      v.initialize(m);
    } else {
      v.initialize(m);
    }
  }


  //second construcor for testing purpose
  public ControllerImp() {

    this.model = new MusicModel(64);
    this.view = new CompositeView();
    hm = new HashMap<>();
    kh = new KeyboardHandler();
    mh = new MouseHandler();
    sb = new StringBuilder();


    //set up for testing purpose
    Map<Character, Runnable> keyTypes = new HashMap<>();
    Map<Integer, Runnable> keyPresses = new HashMap<>();
    Map<Integer, Runnable> keyReleases = new HashMap<>();
    Map<Integer, Runnable> mousePresses = new HashMap<>();


    //operations on composition
    keyPresses.put(KeyEvent.VK_R, new Remove());
    keyPresses.put(KeyEvent.VK_A, new addNote());
    keyPresses.put(KeyEvent.VK_C, new CatchPosition());
    keyPresses.put(KeyEvent.VK_D, new DeleteAll());
    keyPresses.put(KeyEvent.VK_M, new Move1());
    keyReleases.put(KeyEvent.VK_M, new Move2());
    keyPresses.put(KeyEvent.VK_S, new Stop());
    keyPresses.put(KeyEvent.VK_B, new Resume());


    //operation on frame
    keyPresses.put(KeyEvent.VK_RIGHT, new ScrollRight());
    keyPresses.put(KeyEvent.VK_LEFT, new scrollleft());
    keyPresses.put(KeyEvent.VK_UP, new scrollup());
    keyPresses.put(KeyEvent.VK_DOWN, new scrolldown());
    keyPresses.put(KeyEvent.VK_END, new ScrollEnd());
    keyPresses.put(KeyEvent.VK_HOME, new ScrollBegin());


    //map for mouse
    mousePresses.put(0, new MousePress());


    kh.setKeyTypedMap(keyTypes);
    kh.setKeyPressedMap(keyPresses);
    kh.setKeyReleasedMap(keyReleases);

    mh.setMouseClicked(mousePresses);

  }


  /**
   * set up the keyboard handler map
   * Creates and sets a keyboard listener for the view. In effect it creates snippets of code as
   * Runnable object, one for each time a key is typed, pressed and released, only for those that
   * the program needs.
   *
   *
   * Last we create our KeyboardListener object, set all its maps and then give it to the view.
   */

  private void configureKeyBoardListener() {
    Map<Character, Runnable> keyTypes = new HashMap<>();
    Map<Integer, Runnable> keyPresses = new HashMap<>();
    Map<Integer, Runnable> keyReleases = new HashMap<>();
    Map<Integer, Runnable> mousePresses = new HashMap<>();


    //operations on composition
    keyPresses.put(KeyEvent.VK_R, new Remove());
    keyPresses.put(KeyEvent.VK_A, new addNote());
    keyPresses.put(KeyEvent.VK_C, new CatchPosition());
    keyPresses.put(KeyEvent.VK_D, new DeleteAll());
    keyPresses.put(KeyEvent.VK_M, new Move1());
    keyReleases.put(KeyEvent.VK_M, new Move2());
    keyPresses.put(KeyEvent.VK_S, new Stop());
    keyPresses.put(KeyEvent.VK_B, new Resume());


    //operation on frame
    keyPresses.put(KeyEvent.VK_RIGHT, new ScrollRight());
    keyPresses.put(KeyEvent.VK_LEFT, new scrollleft());
    keyPresses.put(KeyEvent.VK_UP, new scrollup());
    keyPresses.put(KeyEvent.VK_DOWN, new scrolldown());
    keyPresses.put(KeyEvent.VK_END, new ScrollEnd());
    keyPresses.put(KeyEvent.VK_HOME, new ScrollBegin());


    //map for mouse
    mousePresses.put(0, new MousePress());

    MouseHandler mh = new MouseHandler();


    KeyboardHandler kbd = new KeyboardHandler();
    kbd.setKeyTypedMap(keyTypes);
    kbd.setKeyPressedMap(keyPresses);
    kbd.setKeyReleasedMap(keyReleases);

    mh.setMouseClicked(mousePresses);

    view.addKeyListener(kbd);
    view.addMouseListener(mh);
  }


  // a get method

  /**
   *
   * @return
   */
  private ArrayList<Pitch> getPitches() {

    Set<Pitch> lop = model.getCollections().keySet();
    ArrayList<Pitch> lop1 = new ArrayList<Pitch>();
    ArrayList<Pitch> lop2 = new ArrayList<Pitch>();


    for (Pitch p : lop) {
      TreeMap<Integer, IBeat> hm1 = model.getCollections().get(p);
      Collection c1 = hm1.values();
      if (!c1.isEmpty()) {
        lop1.add(p);
      }
    }
    int min = lop1.get(0).hashCode();


    // get the pitches that are supposed to be displayed;
    int max = lop1.get(lop1.size() - 1).hashCode();
    for (int l = min; l < max + 1; l++) {
      Pitch p1 = new Pitch(l);
      lop2.add(p1);
    }

    return lop2;
  }

  /**
   * Invoked when an action occurs.
   *
   * this method is responsible for updating vies at a frequency set by the delay time at Timer
   */
  @Override
  public void actionPerformed(ActionEvent e) {
    
  }


  //a Runnable class that will remove some note based on the key and mouse event.
  public class Remove implements Runnable {

    @Override
    public void run() {

      List<Pitch> lop2 = getPitches();

      //reverse the list
      Collections.reverse(lop2);
      Pitch pp = lop2.get(y);
      int pn = pp.pitchNumber();
      HeadBeat hb;

      if (model.getCollections().get(pp).get(x) instanceof HeadBeat) {
        hb = (HeadBeat) model.getCollections().get(pp).get(x);

        int duration = hb.getEnd() - hb.getPosition();
        int instrument = hb.getInstrument();
        int volume = hb.getVolume();
        hm.put(1, duration);
        hm.put(2, instrument);
        hm.put(3, volume);
        view.remove(x, y);
        view.resetFocus();

        model.remove(new Note(new Pitch(pn), duration), hb.getPosition());
        Note n1 = new Note(new Pitch(pn), duration);
        sb.append(n1.getPitch().toString() + " is removed " + " at postion " + hb.getPosition());
      }

    }
  }


  //a Runnable class that will stop the music.
  class Stop implements Runnable {


    @Override
    public void run() {
      view.stop();


    }
  }


  //a Runnable class that will move some note based on the key and mouse event.
  class Move1 implements Runnable {


    @Override
    public void run() {

      new Remove().run();
      view.resetFocus();
    }

  }


  //a Runnable class that will move some note based on the key and mouse event.
  class Move2 implements Runnable {

    @Override
    public void run() {

      try {
        view.move2(x, y, hm.get(1), hm.get(2), hm.get(3));

        List<Pitch> lop2 = getPitches();
        //reverse the list
        Collections.reverse(lop2);
        Pitch pp = lop2.get(y);
        int pn = pp.pitchNumber();

        Note n1 = new Note(new Pitch(pn), hm.get(1));
        n1.Set(x, x + hm.get(1), hm.get(2), pn, hm.get(3));
        model.addNote(n1, x);
        view.resetFocus();
      } catch (NullPointerException e) {
      }
    }
  }


  //a Runnable class that will resume the music
  class Resume implements Runnable {
    @Override
    public void run() {

      view.resume();

    }
  }


  //a Runnable class that will scroll the scrollbar to the right
  class ScrollRight implements Runnable {
    @Override
    public void run() {
      view.scrollright();

    }
  }



  //a Runnable class that will add some note to the compistion
  class addNote implements Runnable {

    public StringBuilder sb;

    public addNote() {
      sb = new StringBuilder();
    }

    ;

    public addNote(StringBuilder sb) {
      this.sb = sb;
    }

    @Override
    public void run() {


      String input1 = JOptionPane.showInputDialog(null, "note duration: \n", "title",
              JOptionPane.PLAIN_MESSAGE);
      int duration = Integer.parseInt(input1);
      String input2 = JOptionPane.showInputDialog(null, "note instrument: \n", "title",
              JOptionPane.PLAIN_MESSAGE);
      int instrument = Integer.parseInt(input2);
      String input3 = JOptionPane.showInputDialog(null, "note volume: \n", "title",
              JOptionPane.PLAIN_MESSAGE);
      int volume = Integer.parseInt(input3);
      view.addNote(x, y, duration, instrument, volume);


      List<Pitch> lop2 = getPitches();
      //reverse the list
      Collections.reverse(lop2);
      Pitch pp = lop2.get(y);
      int pn = pp.pitchNumber();

      Note n1 = new Note(new Pitch(pn), duration);
      n1.Set(x, x + duration, instrument, pn, volume);
      model.addNote(n1, x);

    }
  }



  class MousePress implements Runnable {

    @Override
    public void run() {
    }

  }




  // MouseHandler will be added to the view so user can use mouse to make changes for the music.
  public class MouseHandler implements MouseListener {
    Map<Integer, Runnable> mouseClicked;


    public MouseHandler() {
    }

    ;


    public void setMouseClicked(Map<Integer, Runnable> map) {
      mouseClicked = map;
    }

    /**
     * Invoked when the mouse button has been clicked (pressed and released) on a component.
     */
    @Override
    public void mouseClicked(MouseEvent e) {


      x = (e.getX() - 40) / 20;
      y = (e.getY() - 40) / 20;
      mouseClicked.get(0).run();
    }

    /**
     * Invoked when a mouse button has been pressed on a component.
     */
    @Override
    public void mousePressed(MouseEvent e) {

    }

    /**
     * Invoked when a mouse button has been released on a component.
     */
    @Override
    public void mouseReleased(MouseEvent e) {

    }

    /**
     * Invoked when the mouse enters a component.
     */
    @Override
    public void mouseEntered(MouseEvent e) {

    }

    /**
     * Invoked when the mouse exits a component.
     */
    @Override
    public void mouseExited(MouseEvent e) {

    }
  }


  private class CatchPosition implements Runnable {

    @Override
    public void run() {
      int[] loc = {x, y};
      lop.add(loc);

    }
  }


  // a Runnable class that will delete a few notes at one time
  private class DeleteAll implements Runnable {
    @Override
    public void run() {
      view.deleteAll(lop);
      for (int i = 0; i < lop.size(); i++) {


        List<Pitch> lop2 = getPitches();

        int x = lop.get(i)[0];
        int y = lop.get(i)[1];


        //reverse the list
        Collections.reverse(lop2);
        Pitch pp = lop2.get(y);
        int pn = pp.pitchNumber();
        HeadBeat hb;

        if (model.getCollections().get(pp).get(x) instanceof HeadBeat) {
          hb = (HeadBeat) model.getCollections().get(pp).get(x);

          int duration = hb.getEnd() - hb.getPosition();
          int instrument = hb.getInstrument();
          int volume = hb.getVolume();
          hm.put(1, duration);
          hm.put(2, instrument);
          hm.put(3, volume);
          view.remove(x, y);
          view.resetFocus();
          model.remove(new Note(new Pitch(pn), duration), hb.getPosition());
        }
      }
      lop.clear();


    }
  }

  //a Runnable class that will scroll the scrollbar to the left
  private class scrollleft implements Runnable {
    @Override
    public void run() {
      view.scrollleft();

    }

  }


  //a Runnable class that will scroll the scrollbar  up
  private class scrollup implements Runnable {
    @Override
    public void run() {
      view.scrollup();

    }

  }


  //a Runnable class that will scroll the scrollbar down
  private class scrolldown implements Runnable {
    @Override
    public void run() {
      view.scrolldown();
    }

  }


  //a Runnable class that will scroll the scrollbar to the end of the composition
  private class ScrollEnd implements Runnable {
    @Override
    public void run() {
      view.scrollEnd();
    }
  }


  //a Runnable class that will scroll the scrollbar to the begin of the composition
  private class ScrollBegin implements Runnable {
    public void run() {
      view.scrollBegin();
    }
  }



  //a get method
  public IMusic getModel() {
    return this.model;
  }

  public void setModel(IMusic m) {
    this.model = m;
    view.setModel(m);
  }


  //a get method
  public String getSb() {
    return sb.toString();
  }


}


