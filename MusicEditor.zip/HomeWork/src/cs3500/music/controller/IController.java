package cs3500.music.controller;

/**
 * Created by renyuan on 3/28/16.
 */


// an interface that is responsible for making changes to the composition and the process
//of playing music
public interface IController {

}
