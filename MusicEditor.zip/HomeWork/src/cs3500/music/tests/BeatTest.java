package cs3500.music.tests;

import org.junit.Test;

import cs3500.music.model.HeadBeat;
import cs3500.music.model.IBeat;
import cs3500.music.model.Pitch;
import cs3500.music.model.TailBeat;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created by renyuan on 3/4/16.
 */
public class BeatTest {



  // example for Pitch
  Pitch C1 = new Pitch(1);

  IBeat b1 =new HeadBeat(C1,0,1,60,1);
  IBeat b2 =new TailBeat(C1,1);
  IBeat b3 =new TailBeat(C1,2);




  @Test
  public void testIsOnset()      {
    assertTrue(b1.isOnset());
    assertFalse(b2.isOnset());


  }

  @Test
  public void testToString()      {
    assertEquals("X",(b1.toString()));
    assertEquals("|",(b2.toString()));

  }
}