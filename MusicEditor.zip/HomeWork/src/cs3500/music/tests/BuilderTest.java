package cs3500.music.tests;

import org.junit.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.StringReader;
import java.util.TreeMap;

import cs3500.music.model.HeadBeat;
import cs3500.music.model.IBeat;
import cs3500.music.model.IMusic;
import cs3500.music.model.MusicModel;
import cs3500.music.model.Pitch;
import cs3500.music.model.TailBeat;
import cs3500.music.util.MusicReader;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created by renyuan on 3/23/16.
 */
public class BuilderTest {


  String s2 = new String("" +
          "     D5  D♯5   E5   F5  F♯5\n" +
          " 0             X           \n" +
          " 1             |           \n" +
          " 2                         \n" +
          " 3             X        X  \n" +
          " 4             |        |  \n" +
          " 5                      |  \n" +
          " 6                      |  \n" +
          " 7                         \n" +
          " 8                         \n" +
          " 9   X         X           \n" +
          "10   |         |           \n" +
          "11             |           \n" +
          "12             |           \n" +
          "13             |           \n" +
          "14                         \n" +
          "15                         \n" +
          "16                         \n" +
          "17                         \n" +
          "18                         \n" +
          "19                         \n" +
          "20                         \n" +
          "21                         \n" +
          "22                         \n" +
          "23                         \n" +
          "24                         \n" +
          "25                         \n" +
          "26                         \n" +
          "27                         \n" +
          "28                         \n" +
          "29                         \n" +
          "30                         \n" +
          "31                         \n" +
          "32                         \n" +
          "33                         \n" +
          "34                         \n" +
          "35                         \n" +
          "36                         \n" +
          "37                         \n" +
          "38                         \n" +
          "39                         \n" +
          "40                         \n" +
          "41                         \n" +
          "42                         \n" +
          "43                         \n" +
          "44                         \n" +
          "45                         \n" +
          "46                         \n" +
          "47                         \n" +
          "48                         \n" +
          "49                         \n" +
          "50                         \n" +
          "51                         \n" +
          "52                         \n" +
          "53                         \n" +
          "54                         \n" +
          "55                         \n" +
          "56                         \n" +
          "57                         \n" +
          "58                         \n" +
          "59                         \n" +
          "60                         \n" +
          "61                         \n" +
          "62                         \n" +
          "63                         \n");

  @Test
  public void TestTextView() throws FileNotFoundException {
    // make the builder
    MusicModel.Builder mb = new MusicModel.Builder();
    File file = new File("/Users/renyuan/Desktop/3500/HomeWork/src/cs3500/music/" +
            "mary-little-lamb.txt");
    FileReader fr = new FileReader(file);
    IMusic n11 = MusicReader.parseFile(fr, mb);

    TreeMap<Pitch, TreeMap<Integer, IBeat>> collection = n11.getCollections();

    // the pitch number from give file minus 23 will be equal to the  pitch number I created for the
    // same pitch
    // test if the notes are added or not
    assertEquals(true,collection.get(new Pitch(41)).get(0) instanceof HeadBeat);
    assertEquals(true,collection.get(new Pitch(41)).get(1) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(32)).get(0) instanceof HeadBeat);
    assertTrue(collection.get(new Pitch(32)).get(1) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(32)).get(2) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(32)).get(3) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(32)).get(4) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(32)).get(5) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(32)).get(6) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(39)).get(2) instanceof HeadBeat);
    assertTrue(collection.get(new Pitch(39)).get(3) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(37)).get(4) instanceof HeadBeat);
    assertTrue(collection.get(new Pitch(37)).get(5) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(39)).get(6) instanceof HeadBeat);
    assertTrue(collection.get(new Pitch(32)).get(8) instanceof HeadBeat);
    assertTrue(collection.get(new Pitch(32)).get(9) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(32)).get(10) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(32)).get(11) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(32)).get(12) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(32)).get(13) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(32)).get(14) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(41)).get(8) instanceof HeadBeat);
    assertTrue(collection.get(new Pitch(41)).get(9) instanceof TailBeat);


  }

  @Test
  public void TestTextView1() throws FileNotFoundException {
    // make the builder
    MusicModel.Builder mb = new MusicModel.Builder();
    String sb = new String(" ");
    StringReader sr = new StringReader(sb);
    IMusic n11 = MusicReader.parseFile(sr, mb);
    TreeMap<Pitch, TreeMap<Integer, IBeat>> collection = n11.getCollections();
    // test if the notes are added or not
    assertEquals(false,collection.get(new Pitch(41)).get(0) instanceof HeadBeat);
    assertEquals(false,collection.get(new Pitch(41)).get(1) instanceof TailBeat);
    assertFalse(collection.get(new Pitch(32)).get(0) instanceof HeadBeat);
    assertFalse(collection.get(new Pitch(32)).get(1) instanceof TailBeat);
    assertFalse(collection.get(new Pitch(32)).get(2) instanceof TailBeat);
    assertFalse(collection.get(new Pitch(32)).get(3) instanceof TailBeat);
    assertFalse(collection.get(new Pitch(32)).get(4) instanceof TailBeat);
    assertFalse(collection.get(new Pitch(32)).get(5) instanceof TailBeat);


  }



  // the pitch number from give file minus 23 will be equal to the  pitch number I created for the
  //same pitch
  //test overlap situation
  @Test
  public void TestTextView2() throws FileNotFoundException {
    // make the builder
    MusicModel.Builder mb = new MusicModel.Builder();
    String sb = new String("tempo 71428" +"\n"+
            "note 0 2 1 76 64"  +"\n"+
            "note 3 5 1 76 64" +"\n"+
            "note 3 7 1 78 64" +"\n"+
            "note 9 14 1 76 64" +"\n"+
            "note 9 11 1 74 64"

    );
    StringReader sr = new StringReader(sb);
    IMusic n11 = MusicReader.parseFile(sr, mb);
    TreeMap<Pitch, TreeMap<Integer, IBeat>> collection = n11.getCollections();
    // test if the notes are added or not
    assertEquals(true,collection.get(new Pitch(53)).get(0) instanceof HeadBeat);
    assertEquals(true,collection.get(new Pitch(53)).get(1) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(55)).get(3) instanceof HeadBeat);
    assertTrue(collection.get(new Pitch(55)).get(4) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(55)).get(5) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(55)).get(6) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(51)).get(9) instanceof HeadBeat);
    assertTrue(collection.get(new Pitch(51)).get(10) instanceof TailBeat);
    assertTrue(collection.get(new Pitch(53)).get(12) instanceof TailBeat);

    assertEquals(s2,n11.print());
  }

  // the new notes will completely cover the old ones


}