package cs3500.music.tests;

import org.junit.Test;

import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import javax.swing.*;

import cs3500.music.controller.ControllerImp;
import cs3500.music.controller.KeyboardHandler;
import cs3500.music.model.HeadBeat;
import cs3500.music.model.IBeat;
import cs3500.music.model.IMusic;
import cs3500.music.model.MusicModel;
import cs3500.music.model.Pitch;
import cs3500.music.model.TailBeat;
import cs3500.music.util.MusicReader;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created by renyuan on 4/6/16.
 */
public class ControllerTest {


  class MockRemove implements Runnable {
    public StringBuilder sb;

    public MockRemove() {
      sb = new StringBuilder();
    }

    @Override
    public void run() {
      sb.append("Runnable Remove is initialized by pressing key R");
    }
  }


  class MockAdd implements Runnable {
    public StringBuilder sb;

    public MockAdd() {
      sb = new StringBuilder();
    }

    @Override
    public void run() {
      sb.append("Runnable addNote is initialized by pressing key A");
    }
  }


  class MockMove implements Runnable {
    public StringBuilder sb;

    public MockMove() {
      sb = new StringBuilder();
    }

    @Override
    public void run() {
      sb.append("Runnable MoveNote is initialized by pressing key M");
    }
  }

  class MockStop implements Runnable {
    public StringBuilder sb;

    public MockStop() {
      sb = new StringBuilder();
    }

    @Override
    public void run() {
      sb.append("Runnable Stop is initialized by releasing key S");
    }
  }

  class ScrollRight implements Runnable {
    public StringBuilder sb;

    public ScrollRight() {
      sb = new StringBuilder();
    }

    @Override
    public void run() {
      sb.append("Runnable ScrollRight is initialized by releasing key S");
    }
  }


  class ScrollLeft implements Runnable {
    public StringBuilder sb;

    public ScrollLeft() {
      sb = new StringBuilder();
    }

    @Override
    public void run() {
      sb.append("Runnable ScrollLeft is initialized by releasing key S");
    }
  }


  JFrame Jf = new JFrame();
  KeyboardHandler kbh = new KeyboardHandler();


  KeyEvent KR = new KeyEvent(Jf, 1, 20, 1, KeyEvent.VK_R, 'r');
  KeyEvent KA = new KeyEvent(Jf, 1, 20, 1, KeyEvent.VK_A, 'a');
  KeyEvent KM = new KeyEvent(Jf, 1, 20, 1, KeyEvent.VK_M, 'm');
  KeyEvent KS = new KeyEvent(Jf, 1, 20, 1, KeyEvent.VK_S, 's');
  KeyEvent KT = new KeyEvent(Jf, 1, 20, 1, KeyEvent.VK_T, 's');
  KeyEvent Right = new KeyEvent(Jf, 1, 20, 1, KeyEvent.VK_RIGHT, 'r');
  KeyEvent Left = new KeyEvent(Jf, 1, 20, 1, KeyEvent.VK_LEFT, 'l');


  Map<Integer, Runnable> keyPresses = new HashMap<>();
  Map<Integer, Runnable> keyReleases = new HashMap<>();


  MockRemove MR = new MockRemove();
  MockAdd MA = new MockAdd();
  MockMove MM = new MockMove();
  MockStop MS = new MockStop();
  ScrollRight SR = new ScrollRight();
  ScrollLeft SL = new ScrollLeft();


  public void setUpKeyboardMaps() {


    keyPresses.put(KeyEvent.VK_R, MR);
    keyPresses.put(KeyEvent.VK_A, MA);
    keyPresses.put(KeyEvent.VK_M, MM);
    keyPresses.put(KeyEvent.VK_RIGHT, SR);
    keyPresses.put(KeyEvent.VK_LEFT, SL);
    keyReleases.put(KeyEvent.VK_S, MS);
    kbh.setKeyPressedMap(keyPresses);
    kbh.setKeyReleasedMap(keyReleases);

  }


  @Test
  public void TestKeyboardHandler1() {

    setUpKeyboardMaps();
    kbh.keyPressed(KR);
    kbh.keyPressed(KA);
    kbh.keyPressed(KM);
    kbh.keyReleased(KS);
    kbh.keyPressed(Right);
    kbh.keyPressed(Left);


    assertEquals("Runnable Remove is initialized by pressing key R", MR.sb.toString());
    assertEquals("Runnable addNote is initialized by pressing key A", MA.sb.toString());
    assertEquals("Runnable MoveNote is initialized by pressing key M", MM.sb.toString());
    assertEquals("Runnable Stop is initialized by releasing key S", MS.sb.toString());
    assertEquals("Runnable ScrollRight is initialized by releasing key S", SR.sb.toString());
    assertEquals("Runnable ScrollLeft is initialized by releasing key S", SL.sb.toString());

  }

  @Test
  public void TestKeyboardHandler2() {
    setUpKeyboardMaps();


    kbh.keyReleased(KR);
    assertEquals("", MR.sb.toString());

    kbh.keyPressed(KT);
    assertEquals("", MS.sb.toString());

    kbh.keyPressed(KR);
    assertEquals("Runnable Remove is initialized by pressing key R", MR.sb.toString());
  }


  class MockMouseClicked implements Runnable {
    public StringBuilder sb;

    public MockMouseClicked() {
      sb = new StringBuilder();
    }

    @Override
    public void run() {
      sb.append("Mouse has been clicked");
    }
  }

  ControllerImp.MouseHandler mh = new ControllerImp().new MouseHandler();
  Map<Integer, Runnable> mouseClicked = new HashMap<>();

  MouseEvent MEvent = new MouseEvent(Jf, 1, 2, 0, 40, 100, 1, true);
//
//  Jf, 1, 2, 0, 30, 40, 1, true

  MockMouseClicked MMC = new MockMouseClicked();


  @Test
  public void TestMouseHandler1() {

    mouseClicked.put(MEvent.getButton(), MMC);
    mh.setMouseClicked(mouseClicked);
    mh.mouseClicked(MEvent);


    assertEquals("Mouse has been clicked", MMC.sb.toString());

  }


  ControllerImp contr = new ControllerImp();

  MusicModel.Builder mb = new MusicModel.Builder();
  File file = new File("/Users/renyuan/Desktop/3500/HomeWork/src/cs3500/musi" +
          "c/mary-little-lamb.txt");


  @Test
  public void TestController1() throws FileNotFoundException {

    FileReader fr = new FileReader(file);
    IMusic n11 = MusicReader.parseFile(fr, mb);


//    TreeMap<Pitch,TreeMap<Integer,IBeat>> tm = contr.getModel().getCollections();


    contr.setModel(n11);
    TreeMap<Pitch, TreeMap<Integer, IBeat>> collections = contr.getModel().getCollections();

    TreeMap<Integer, IBeat> tm1 = collections.get(new Pitch(41));


    //test at a certain position there is beat in the composition
    assertTrue(tm1.get(0) instanceof HeadBeat);
    assertTrue(tm1.get(1) instanceof TailBeat);
    contr.mh.mouseClicked(MEvent);
    contr.kh.keyPressed(KR);


    //after the keyboard and mouse operation, a certain note is removed
    assertEquals("E4 is removed  at postion 0", contr.getSb());
    assertFalse(tm1.get(0) instanceof HeadBeat);
    assertFalse(tm1.get(1) instanceof TailBeat);


  }


  // new keyevent for another position
  MouseEvent MEvent2 = new MouseEvent(Jf, 1, 2, 0, 80, 140, 1, true);


  @Test
  public void TestController2() throws FileNotFoundException {

    FileReader fr = new FileReader(file);
    IMusic n11 = MusicReader.parseFile(fr, mb);


//    TreeMap<Pitch,TreeMap<Integer,IBeat>> tm = contr.getModel().getCollections();

    contr.setModel(n11);
    TreeMap<Pitch, TreeMap<Integer, IBeat>> collections = contr.getModel().getCollections();

    TreeMap<Integer, IBeat> tm1 = collections.get(new Pitch(39));
    System.out.print(tm1.toString());

    //test at a certain position there is beat in the composition
    assertTrue(tm1.get(2) instanceof HeadBeat);
    assertTrue(tm1.get(3) instanceof TailBeat);
    contr.mh.mouseClicked(MEvent2);
    contr.kh.keyPressed(KR);


    //after the keyboard and mouse operation, a certain note is removed
    assertEquals("D4 is removed  at postion 2", contr.getSb());
    assertFalse(tm1.get(2) instanceof HeadBeat);
    assertFalse(tm1.get(3) instanceof TailBeat);

  }


}