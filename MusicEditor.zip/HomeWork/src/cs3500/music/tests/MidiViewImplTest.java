package cs3500.music.tests;

import org.junit.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.StringReader;

import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiUnavailableException;

import cs3500.music.model.IMusic;
import cs3500.music.model.MusicModel;
import cs3500.music.util.MusicReader;
import cs3500.music.view.MidiViewImpl;
import cs3500.music.view.MockReceiver;
import cs3500.music.view.MockSynth;

import static org.junit.Assert.assertEquals;

/**
 * Created by renyuan on 3/22/16.
 */



public class MidiViewImplTest {



  String s1 = new String("Start Position: 0   PitchNumber: 55   Volume: 70   Channel: 1  " +
          " Status note on\n" +
          "Start Position: 0   PitchNumber: 64   Volume: 72   Channel: 1   Status note on\n" +
          "End Position:   2   PitchNumber: 64   Volume: 72   Channel: 1   Status note off\n" +
          "Start Position: 2   PitchNumber: 62   Volume: 72   Channel: 1   Status note on\n" +
          "End Position:   4   PitchNumber: 62   Volume: 72   Channel: 1   Status note off\n" +
          "Start Position: 4   PitchNumber: 60   Volume: 71   Channel: 1   Status note on\n" +
          "End Position:   6   PitchNumber: 60   Volume: 71   Channel: 1   Status note off\n" +
          "Start Position: 6   PitchNumber: 62   Volume: 79   Channel: 1   Status note on\n" +
          "End Position:   7   PitchNumber: 55   Volume: 70   Channel: 1   Status note off\n" +
          "End Position:   8   PitchNumber: 62   Volume: 79   Channel: 1   Status note off\n" +
          "Start Position: 8   PitchNumber: 55   Volume: 79   Channel: 1   Status note on\n" +
          "Start Position: 8   PitchNumber: 64   Volume: 85   Channel: 1   Status note on\n" +
          "End Position:   10   PitchNumber: 64   Volume: 85   Channel: 1   Status note off\n" +
          "Start Position: 10   PitchNumber: 64   Volume: 78   Channel: 1   Status note on\n" +
          "End Position:   12   PitchNumber: 64   Volume: 78   Channel: 1   Status note off\n" +
          "Start Position: 12   PitchNumber: 64   Volume: 74   Channel: 1   Status note on\n" +
          "End Position:   15   PitchNumber: 55   Volume: 79   Channel: 1   Status note off\n" +
          "End Position:   15   PitchNumber: 64   Volume: 74   Channel: 1   Status note off\n" +
          "Start Position: 16   PitchNumber: 55   Volume: 77   Channel: 1   Status note on\n" +
          "Start Position: 16   PitchNumber: 62   Volume: 75   Channel: 1   Status note on\n" +
          "End Position:   18   PitchNumber: 62   Volume: 75   Channel: 1   Status note off\n" +
          "Start Position: 18   PitchNumber: 62   Volume: 77   Channel: 1   Status note on\n" +
          "End Position:   20   PitchNumber: 62   Volume: 77   Channel: 1   Status note off\n" +
          "Start Position: 20   PitchNumber: 62   Volume: 75   Channel: 1   Status note on\n" +
          "End Position:   24   PitchNumber: 55   Volume: 77   Channel: 1   Status note off\n" +
          "End Position:   24   PitchNumber: 62   Volume: 75   Channel: 1   Status note off\n" +
          "Start Position: 24   PitchNumber: 55   Volume: 79   Channel: 1   Status note on\n" +
          "Start Position: 24   PitchNumber: 64   Volume: 82   Channel: 1   Status note on\n" +
          "End Position:   26   PitchNumber: 55   Volume: 79   Channel: 1   Status note off\n" +
          "End Position:   26   PitchNumber: 64   Volume: 82   Channel: 1   Status note off\n" +
          "Start Position: 26   PitchNumber: 67   Volume: 84   Channel: 1   Status note on\n" +
          "End Position:   28   PitchNumber: 67   Volume: 84   Channel: 1   Status note off\n" +
          "Start Position: 28   PitchNumber: 67   Volume: 75   Channel: 1   Status note on\n" +
          "End Position:   32   PitchNumber: 67   Volume: 75   Channel: 1   Status note off\n" +
          "Start Position: 32   PitchNumber: 55   Volume: 78   Channel: 1   Status note on\n" +
          "Start Position: 32   PitchNumber: 64   Volume: 73   Channel: 1   Status note on\n" +
          "End Position:   34   PitchNumber: 64   Volume: 73   Channel: 1   Status note off\n" +
          "Start Position: 34   PitchNumber: 62   Volume: 69   Channel: 1   Status note on\n" +
          "End Position:   36   PitchNumber: 62   Volume: 69   Channel: 1   Status note off\n" +
          "Start Position: 36   PitchNumber: 60   Volume: 71   Channel: 1   Status note on\n" +
          "End Position:   38   PitchNumber: 60   Volume: 71   Channel: 1   Status note off\n" +
          "Start Position: 38   PitchNumber: 62   Volume: 80   Channel: 1   Status note on\n" +
          "End Position:   40   PitchNumber: 55   Volume: 78   Channel: 1   Status note off\n" +
          "End Position:   40   PitchNumber: 62   Volume: 80   Channel: 1   Status note off\n" +
          "Start Position: 40   PitchNumber: 55   Volume: 79   Channel: 1   Status note on\n" +
          "Start Position: 40   PitchNumber: 64   Volume: 84   Channel: 1   Status note on\n" +
          "End Position:   42   PitchNumber: 64   Volume: 84   Channel: 1   Status note off\n" +
          "Start Position: 42   PitchNumber: 64   Volume: 76   Channel: 1   Status note on\n" +
          "End Position:   44   PitchNumber: 64   Volume: 76   Channel: 1   Status note off\n" +
          "Start Position: 44   PitchNumber: 64   Volume: 74   Channel: 1   Status note on\n" +
          "End Position:   46   PitchNumber: 64   Volume: 74   Channel: 1   Status note off\n" +
          "Start Position: 46   PitchNumber: 64   Volume: 77   Channel: 1   Status note on\n" +
          "End Position:   48   PitchNumber: 55   Volume: 79   Channel: 1   Status note off\n" +
          "End Position:   48   PitchNumber: 64   Volume: 77   Channel: 1   Status note off\n" +
          "Start Position: 48   PitchNumber: 55   Volume: 78   Channel: 1   Status note on\n" +
          "Start Position: 48   PitchNumber: 62   Volume: 75   Channel: 1   Status note on\n" +
          "End Position:   50   PitchNumber: 62   Volume: 75   Channel: 1   Status note off\n" +
          "Start Position: 50   PitchNumber: 62   Volume: 74   Channel: 1   Status note on\n" +
          "End Position:   52   PitchNumber: 62   Volume: 74   Channel: 1   Status note off\n" +
          "Start Position: 52   PitchNumber: 64   Volume: 81   Channel: 1   Status note on\n" +
          "End Position:   54   PitchNumber: 64   Volume: 81   Channel: 1   Status note off\n" +
          "Start Position: 54   PitchNumber: 62   Volume: 70   Channel: 1   Status note on\n" +
          "End Position:   56   PitchNumber: 55   Volume: 78   Channel: 1   Status note off\n" +
          "End Position:   56   PitchNumber: 62   Volume: 70   Channel: 1   Status note off\n" +
          "Start Position: 56   PitchNumber: 52   Volume: 72   Channel: 1   Status note on\n" +
          "Start Position: 56   PitchNumber: 60   Volume: 73   Channel: 1   Status note on\n" );


  @Test
  public void TestMidi1() throws FileNotFoundException, InvalidMidiDataException,
          InterruptedException, MidiUnavailableException {
  MusicModel.Builder mb = new MusicModel.Builder();
  File file = new File("/Users/renyuan/Desktop/3500/HomeWork/src/cs3500/music" +
          "/mary-little-lamb.txt");
  FileReader fr = new FileReader(file);
  IMusic n11 = MusicReader.parseFile(fr,mb);

    MidiViewImpl midi = new MidiViewImpl(new MockSynth(),new MockReceiver());

    midi.initialize(n11);
    MockReceiver mr = (MockReceiver) midi.getReceiver();
    assertEquals(s1,(mr.getSb()).toString());
  }



  //test for situation that on notes on the file
  @Test
  public void TestMidi2() throws FileNotFoundException, InvalidMidiDataException,
          InterruptedException, MidiUnavailableException {
    MusicModel.Builder mb = new MusicModel.Builder();

    String sb = new String(" ");
    StringReader sr = new StringReader(sb);
    IMusic n11 = MusicReader.parseFile(sr,mb);
    MidiViewImpl midi = new MidiViewImpl(new MockSynth(),new MockReceiver());

    midi.initialize(n11);
    MockReceiver mr = (MockReceiver) midi.getReceiver();
    assertEquals("",(mr.getSb()).toString());
  }

}