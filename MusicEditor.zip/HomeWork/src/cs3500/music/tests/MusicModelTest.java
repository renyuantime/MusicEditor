package cs3500.music.tests;

import org.junit.Test;

import cs3500.music.model.HeadBeat;
import cs3500.music.model.IMusic;
import cs3500.music.model.MusicModel;
import cs3500.music.model.Note;
import cs3500.music.model.Pitch;
import cs3500.music.model.TailBeat;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

/**
 * Created by renyuan on 3/3/16.
 */
public class MusicModelTest {

  // example for Pitch
  Pitch C1 = new Pitch(1);
  Pitch G4 = new Pitch(Pitch.MusicPitch.G,4);
  Pitch E4 = new Pitch(Pitch.MusicPitch.E,4);
  Pitch D4 = new Pitch(Pitch.MusicPitch.D,4);
  Pitch C4 = new Pitch(Pitch.MusicPitch.C,4);
  Pitch G3 = new Pitch(Pitch.MusicPitch.G,3);
  Pitch G3S = new Pitch(Pitch.MusicPitch.GSharp,3);
  Pitch E3 = new Pitch(Pitch.MusicPitch.E,3);
  Pitch D10 = new Pitch(Pitch.MusicPitch.DSharp,10);
  Pitch GS3 = new Pitch(Pitch.MusicPitch.GSharp,3);
  Pitch B10 = new Pitch(Pitch.MusicPitch.B,10);




  //Example for notes
  Note C12 = new Note(C1,2);

  Note G42 = new Note(G4,2);
  Note G44 = new Note(G4,4);

  Note E42 = new Note(E4,2);
  Note E43 = new Note(E4,3);

  Note D42 = new Note(D4,2);
  Note D44 = new Note(D4,4);

  Note C42= new Note(C4,2);
  Note C48= new Note(C4,8);


  Note G32 = new Note(G3,2);
  Note G37= new Note(G3,7);
  Note G38 = new Note(G3,8);
  Note G3S8 = new Note(G3S,8);

  Note E38 = new Note(E3,8);

  Note D108 = new Note(D10,8);

  Note GS32 = new Note(GS3,2);

  Note B102 = new Note(B10,2);



  //Example for MusicModels
  IMusic nc1 = new MusicModel(64);
  IMusic nc2 = new MusicModel(64);




  @Test
  public void testAddNote1()  {
    nc1.prepareAddNote();
    nc1.addNote(G42,26);
    nc1.addNote(G44,28);
    nc1.addNote(D108,24);

    // test that if the method really put the beat into position
    assertFalse(nc1.getCollections().get(G4).get(25) instanceof HeadBeat);
    assertTrue(nc1.getCollections().get(G4).get(26) instanceof HeadBeat);
    assertTrue(nc1.getCollections().get(G4).get(27) instanceof TailBeat);
    assertTrue(nc1.getCollections().get(G4).get(28) instanceof HeadBeat);
    assertTrue(nc1.getCollections().get(D10).get(24) instanceof HeadBeat);
    assertTrue(nc1.getCollections().get(D10).get(25) instanceof TailBeat);
    assertTrue(nc1.getCollections().get(D10).get(31) instanceof TailBeat);
    assertFalse(nc1.getCollections().get(D10).get(32) instanceof TailBeat);
  }


  @Test(expected = IllegalArgumentException.class)
  public void TestAddNoteException1(){
    nc1.prepareAddNote();
    nc1.addNote(G42,-1);
  }






  @Test
  public void testRemove()  {
    nc1.prepareAddNote();
    nc1.addNote(G32,0);

    //add the notes first
    assertTrue(nc1.getCollections().get(G3).get(0) instanceof HeadBeat);
    assertTrue(nc1.getCollections().get(G3).get(1) instanceof TailBeat);

    // then remove the note
    nc1.remove(G32,0);
    assertFalse(nc1.getCollections().get(G3).get(0) instanceof HeadBeat);
    assertFalse(nc1.getCollections().get(G3).get(1) instanceof TailBeat);
  }


  @Test(expected = IllegalArgumentException.class)
  public void TestRemoveNoteException1(){
    nc1.prepareAddNote();
    nc1.addNote(G42,0);
    nc1.remove(G42,-1);
  }
  
  
  @Test
  public void testRise1(){
    //add note first
    nc1.prepareAddNote();
    nc1.addNote(G38,0);

    //test if the note is added or not
    assertTrue(nc1.getCollections().get(G3).get(0) instanceof  HeadBeat);
    assertTrue(nc1.getCollections().get(G3).get(1) instanceof  TailBeat);



    //rise the note, so this note will appear at same time position but a higher pitch
    nc1.rise(G38,0);
    assertFalse(nc1.getCollections().get(G3).get(0) instanceof  HeadBeat);
    assertFalse(nc1.getCollections().get(G3).get(1) instanceof  TailBeat);
    assertTrue(nc1.getCollections().get(G3S).get(0) instanceof  HeadBeat);
    assertTrue(nc1.getCollections().get(G3S).get(1) instanceof  TailBeat);
  }

  @Test(expected = IllegalArgumentException.class)
  public void TestRiseException1(){
    nc1.prepareAddNote();
    nc1.addNote(B102,0);
    nc1.rise(B102,0);
  }


  @Test
  public void testfall1(){
    //add note first
    nc1.prepareAddNote();
    nc1.addNote(G3S8,0);

    //test if the note is added or not
    assertTrue(nc1.getCollections().get(G3S).get(0) instanceof  HeadBeat);
    assertTrue(nc1.getCollections().get(G3S).get(1) instanceof  TailBeat);



    //lower the note, so this note will appear at same time position but a lower pitch
    nc1.fall(G3S8,0);
    assertFalse(nc1.getCollections().get(G3S).get(0) instanceof  HeadBeat);
    assertFalse(nc1.getCollections().get(G3S).get(1) instanceof  TailBeat);
    assertTrue(nc1.getCollections().get(G3).get(0) instanceof  HeadBeat);
    assertTrue(nc1.getCollections().get(G3).get(1) instanceof  TailBeat);
  }

  @Test(expected = IllegalArgumentException.class)
  public void TestFallException1(){
    nc1.prepareAddNote();
    nc1.addNote(C12,0);
    nc1.fall(C12,0);
  }


  @Test
  public void TestPlayplaySimultaneously(){
    nc1.prepareAddNote();
    nc2.prepareAddNote();

    nc1.addNote(G37,0);
    nc2.addNote(E42,0);


    //nc1 has added note G37
    nc1.playSimultaneously(nc2);
    assertTrue(nc1.getCollections().get(G3).get(0) instanceof HeadBeat);
    assertTrue(nc1.getCollections().get(G3).get(1) instanceof TailBeat);
    assertTrue(nc1.getCollections().get(G3).get(2) instanceof TailBeat);


    //nc1 has added all the notes from nc2
    assertTrue(nc1.getCollections().get(E4).get(0) instanceof HeadBeat);
    assertTrue(nc1.getCollections().get(E4).get(1) instanceof TailBeat);
    assertFalse(nc1.getCollections().get(E4).get(2) instanceof TailBeat);

  }

  @Test
  public void TestPlayConsecutively(){
    nc1.prepareAddNote();
    nc2.prepareAddNote();

    nc1.addNote(G37,0);
    nc2.addNote(E42,0);

    nc1.playConsecutively(nc2);

    //nc1 has added note G37
    nc1.playSimultaneously(nc2);
    assertTrue(nc1.getCollections().get(G3).get(0) instanceof HeadBeat);
    assertTrue(nc1.getCollections().get(G3).get(1) instanceof TailBeat);
    assertTrue(nc1.getCollections().get(G3).get(2) instanceof TailBeat);


    //nc1 has added all the notes from nc2 after is played, which is at position 64
    assertTrue(nc1.getCollections().get(E4).get(64) instanceof HeadBeat);
    assertTrue(nc1.getCollections().get(E4).get(65) instanceof TailBeat);
    assertFalse(nc1.getCollections().get(E4).get(66) instanceof TailBeat);
  }


  // test situation that no notes in the compistion
  @Test
  public void testNoNotes(){
    nc1.prepareAddNote();
    assertFalse(nc1.getCollections().get(G3).get(0) instanceof HeadBeat);
    assertFalse(nc1.getCollections().get(G3).get(1) instanceof TailBeat);
    assertFalse(nc1.getCollections().get(G3).get(2) instanceof TailBeat);
    assertFalse(nc1.getCollections().get(G3).get(3) instanceof TailBeat);
    assertFalse(nc1.getCollections().get(G3).get(4) instanceof TailBeat);
    assertFalse(nc1.getCollections().get(G3).get(5) instanceof TailBeat);
  }


}