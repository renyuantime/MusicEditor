package cs3500.music.tests;

import org.junit.Test;

import cs3500.music.model.Note;
import cs3500.music.model.Pitch;

import static org.junit.Assert.assertEquals;

/**
 * Created by renyuan on 3/4/16.
 */
public class NoteTest {

  Pitch p1 = new Pitch(1);
  Pitch p2 = new Pitch(2);
  Pitch p12 = new Pitch(12);
  Pitch p13 = new Pitch(13);

  Note n1 = new Note(p1,2);
  Note n2 = new Note(p2,2);
  Note n12 = new Note(p12,8);
  Note n13 = new Note(p13,8);



  @Test
  public void testRise()  {
    n1.rise();
    assertEquals("C♯1",n1.getPitch().toString());
    assertEquals("B1", n12.getPitch().toString());
    n12.rise();
    assertEquals("C2", n12.getPitch().toString());
  }

  @Test
  public void testFall()  {
    n2.fall();
    assertEquals("C1",n1.getPitch().toString());
    assertEquals("B1", n12.getPitch().toString());
    n12.fall();
    assertEquals("A♯1", n12.getPitch().toString());
  }
}