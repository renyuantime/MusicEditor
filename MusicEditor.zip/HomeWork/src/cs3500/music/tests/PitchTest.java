package cs3500.music.tests;

import org.junit.Test;

import cs3500.music.model.Pitch;

import static org.junit.Assert.assertEquals;

/**
 * Created by renyuan on 3/3/16.
 */
public class PitchTest {

  Pitch p1 = new Pitch(Pitch.MusicPitch.CSharp,3);
  Pitch p2 = new Pitch(1);
  Pitch p10 = new Pitch(120);
  Pitch p3 = new Pitch(31);
  Pitch pc4 = new Pitch(37);

  @Test
  public void TestToString1(){

    assertEquals("C♯3",p1.toString());
  }
  @Test
  public void TestToString2()
  {

    //test for IntCovernToPitch
    assertEquals("C1", p1.IntCoverntToPitch(1).toString());
    assertEquals("E3", new Pitch(29).toString());
    assertEquals("E3", p1.IntCoverntToPitch(29).toString());
    assertEquals("C4", new Pitch(37).toString());
  }


}