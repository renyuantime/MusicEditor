package cs3500.music.tests;

import org.junit.Test;

import cs3500.music.view.GuiViewFrame;
import cs3500.music.view.IMusicView;
import cs3500.music.view.MidiViewImpl;
import cs3500.music.view.TextView;
import cs3500.music.view.ViewFactory;

import static org.junit.Assert.assertTrue;

/**
 * Created by renyuan on 3/23/16.
 */
public class ViewFactoryTest {


  @Test
  public void TestViewFactory1(){
    ViewFactory vf = new ViewFactory();
    IMusicView midi = vf.makeView("midi");
    IMusicView text = vf.makeView("console");
    IMusicView visiual = vf.makeView("visual");

    assertTrue(midi instanceof MidiViewImpl);
    assertTrue(text instanceof TextView);
    assertTrue(visiual instanceof GuiViewFrame);
  }
}