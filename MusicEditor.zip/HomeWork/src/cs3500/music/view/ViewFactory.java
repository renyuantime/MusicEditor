package cs3500.music.view;

/**
 * Created by renyuan on 3/16/16.
 */
public class ViewFactory {

  public ViewFactory() {
  }

  ;


  /**
   * make view based on the input
   * @param viewName the input view name
   * @return
   */
  public IMusicView makeView(String viewName) {
    if (viewName.equals("midi")) {
      return new MidiViewImpl();
    } else if (viewName.equals("console")) {
      return new TextView();
    } else if (viewName.equals("visual")) {
      return new GuiViewFrame();
    } else if (viewName.equals("both")) {
      return new CompositeView();
    } else throw new IllegalArgumentException();
  }

}
